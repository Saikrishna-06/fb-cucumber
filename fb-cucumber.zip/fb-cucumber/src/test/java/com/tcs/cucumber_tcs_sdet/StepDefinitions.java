package com.tcs.cucumber_tcs_sdet;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import pom.Login;
import utils.Common;

import org.junit.platform.suite.api.AfterSuite;
import org.junit.platform.suite.api.BeforeSuite;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class StepDefinitions {

	static WebDriver driver;
	String browser = "chrome";
	String url = "https://www.facebook.com";
	Common common;

	@Before
	public void setup() {
		common = new Common();
		common.setuBrowser(browser, url);
		driver = common.getDriverObject();
	}

	@After
	public void tearDown() {
		common.quitBrowser();
	}

	public void compareResults(String expectedResult, String actualResult) {
		assert (actualResult.equals(expectedResult));
	}
	@Given("I am on the login page")
	public void i_am_on_the_login_page() {
		driver.navigate().to(url);
	}

	@Then("url should be displayed")
	public void url_should_be_displayed() {
		String expectedResult = "https://www.facebook.com/";
		String actualResult = driver.getCurrentUrl();
		compareResults(expectedResult, actualResult);
	}

	@Then("Page title should be displayed")
	public void page_title_should_be_displayed() {
		String expectedResult = "Facebook – log in or sign up";
		String actualResult = driver.getTitle();
		compareResults(expectedResult, actualResult);
	}

	@Then("Welcome message should be displayed")
	public void welcome_message_should_be_displayed() {

		String expectedResult = "Facebook helps you connect and share with the people in your life.";
		Login login = new Login(driver);
		String actualResult = login.getWelcomeMessage();
		compareResults(expectedResult, actualResult);
	}

	@Then("username textbox placeholder should be displayed")
	public void username_textbox_placeholder_should_be_displayed() {
		String expectedResult = "Email address or phone number";
		Login login = new Login(driver);
		String actualResult = login.getEmailPlaceholder();
		compareResults(expectedResult, actualResult);
	}

	@Then("Password placeholder should be displayed")
	public void password_placeholder_should_be_displayed() {
		String expectedResult = "Password";
		Login login = new Login(driver);
		String actualResult = login.getPasswordPlaceholder();
		compareResults(expectedResult, actualResult);
	}

	@Then("login button text should be displayed")
	public void login_button_text_should_be_displayed() {
		String expectedResult = "Log in";
		Login login = new Login(driver);
		String actualResult = login.getLoginButtonText();
		compareResults(expectedResult, actualResult);
	}

}
